export const videoData = [
    {
        id: 0,
        name: "Funny Cat Video!!!",
        author: "CatLover332",
        length: "1:20",
        thumbnail: "FunnyCatVideo_thumbnail.jpg",
        date: "05/09/2009",
        vidSrc: "https://www.youtube.com/embed/DHfRfU3XUEo?si=pjyztRslM_z0rUjf"
    },

     {
        id: 1,
        name: "How to fix Xampp | 2025 Edition",
        author: "Graham",
        length: "40:67",
        thumbnail: "HowToFixXampp2025Edition_thumbnail.png",
        date: "02/04/2025",
        vidSrc: "https://www.youtube.com/embed/dQw4w9WgXcQ?si=NPIgZfNXu-avC_tQ"
    },

    {
        id: 2,
        name: "Seal farts after looking at me",
        author: "Steve Blobs",
        length: "0:12",
        thumbnail: "SealFarts_thumbnail.png",
        date: "17/07/2015",
        vidSrc: "https://www.youtube.com/embed/w4BoNlGa7gM?si=LD14kBkdS3n4B9qz"
    },

    {
        id: 3,
        name: "Tips For Unity",
        author: "How2Unity",
        length: "20:34",
        thumbnail: "TipsForUnity_thumbnail.png",
        date: "12/06/2023",
        vidSrc: "https://www.youtube.com/embed/fmbYlYU7z9Y?si=XY2o12CoQTkoFEEZ"
    },

    {
        id: 4,
        name: "A beginners guide to world domination",
        author: "Pinky&Brain",
        length: "456:49",
        thumbnail: "worldDomination_thumbnail.png",
        date: "12/06/2023"
    },

    {
        id: 5,
        name: "How Quake 2's BFG works",
        author: "Decino",
        length: "12:34",
        thumbnail: "HowQuake2sBFGWorks_thumbnail.png",
        date: "05/08/2024",
        vidSrc: "https://www.youtube.com/embed/2KL89T9T9UA?si=w809EROLH45wbLy1"
    },

];

